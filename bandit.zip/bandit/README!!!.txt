/**
 * UPDATE : 2 February 2021
 * https://blacknetid.pw
 * github.com/zlaxtert
 * Recode Only Makes You a Loser
 * I'M ALONE
 * Chat Me @Alone_code404 (Telegram)
 * Follow Me @zlaxtert (Instagram)
 * I'm a coder KENTANG
 * IZROIL MY FRIEND FOREVER
 */
 
!!! WARNING !!! 
This script is updated by ZLAXTERT.! 
Please don't change the script and sell this script.! 

FOLLOW US!!

TELEGRAM : @Alone_code404
INSTAGRAM : @BLACKNETID
WEBSITE : HTTPS://BLACKNETID.PW

OWNER :

1. DANDY (FACEBOOK) => https://www.facebook.com/dandi.darmawan19

2. TAUFIK (FACEBOOK) => https://www.facebook.com/centong.sayur.180


=========[COMMAND]=========


1. EXTRACK FILE DI DALAM FOLDER DOWNLOADS
2. termux-setup-storage
   (Ijinkan aksess / Y)
3. cd storage/downloads/bandit

4. pkg install php

5. php bandit.php
6. Enjoy

===[THANKS FOR USING]===